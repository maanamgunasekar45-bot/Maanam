
import React, { useState } from 'react';
import { ProductType, ProductPrices } from '../types';

interface SettingsModalProps {
  prices: ProductPrices;
  onClose: () => void;
  onSave: (p: ProductPrices) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ prices, onClose, onSave }) => {
  const [localPrices, setLocalPrices] = useState(prices);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(localPrices);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden">
        <div className="bg-slate-800 p-6 flex justify-between items-center">
            <h2 className="text-white font-black uppercase tracking-widest text-sm">Update Fuel Prices</h2>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {Object.values(ProductType).map(type => (
            <div key={type}>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">{type} Price (₹/L)</label>
              <input 
                type="number" step="0.01" 
                value={localPrices[type]} 
                onChange={e => setLocalPrices({...localPrices, [type]: parseFloat(e.target.value) || 0})}
                className="w-full p-3 border rounded-xl font-black text-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>
          ))}
          <div className="flex gap-2 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-3 text-xs font-bold text-slate-500">Cancel</button>
            <button type="submit" className="flex-1 py-3 text-xs font-black text-white bg-indigo-600 rounded-xl">Save Prices</button>
          </div>
        </form>
      </div>
    </div>
  );
};
