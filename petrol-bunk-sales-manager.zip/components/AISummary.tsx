
// This component is currently disabled to maintain dashboard simplicity.
export default null;
