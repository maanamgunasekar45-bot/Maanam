
import React, { useState, useEffect, useMemo } from 'react';
import { ProductType, DailySummary, ProductPrices } from './types';
import { Header } from './components/Header';
import { SummaryCards } from './components/SummaryCards';
import { EntryModal } from './components/EntryModal';
import { SettingsModal } from './components/SettingsModal';

const App: React.FC = () => {
  const getTodayISO = () => new Date().toISOString().split('T')[0];

  const [entries, setEntries] = useState<DailySummary[]>([]);
  const [viewDate, setViewDate] = useState<string>(getTodayISO());
  
  const [prices, setPrices] = useState<ProductPrices>({
    [ProductType.MS]: 109.83,
    [ProductType.HSD]: 97.6,
    [ProductType.XP95]: 116.89
  });

  const [isEntryOpen, setIsEntryOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Storage key uniquely identifies this private app instance
  const STORAGE_ENTRIES = 'bunk_manager_private_entries';
  const STORAGE_PRICES = 'bunk_manager_private_prices';

  useEffect(() => {
    const savedEntries = localStorage.getItem(STORAGE_ENTRIES);
    const savedPrices = localStorage.getItem(STORAGE_PRICES);
    if (savedEntries) setEntries(JSON.parse(savedEntries));
    if (savedPrices) setPrices(JSON.parse(savedPrices));
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_ENTRIES, JSON.stringify(entries));
  }, [entries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_PRICES, JSON.stringify(prices));
  }, [prices]);

  const handleAddEntry = (newEntry: DailySummary) => {
    setEntries(prev => [...prev, newEntry]);
    setViewDate(newEntry.date);
  };

  const handleReset = () => {
    if (window.confirm(`Clear all data for ${new Date(viewDate).toLocaleDateString()}?`)) {
      setEntries(prev => prev.filter(e => e.date !== viewDate));
    }
  };

  const dashboardData = useMemo(() => {
    const dailyEntries = entries.filter(e => e.date === viewDate);
    
    const totals = dailyEntries.reduce((acc, curr) => ({
      hsdLiters: acc.hsdLiters + curr.hsdLiters,
      msLiters: acc.msLiters + curr.msLiters,
      xp95Liters: acc.xp95Liters + curr.xp95Liters,
      ccReceivables: acc.ccReceivables + curr.ccReceivables,
      testingAmount: acc.testingAmount + curr.testingAmount,
      debtors: acc.debtors + curr.debtors,
      otherExpenses: acc.otherExpenses + curr.otherExpenses,
    }), {
      hsdLiters: 0, msLiters: 0, xp95Liters: 0, ccReceivables: 0, testingAmount: 0, debtors: 0, otherExpenses: 0
    });

    const hsdRevenue = totals.hsdLiters * prices[ProductType.HSD];
    const msRevenue = totals.msLiters * prices[ProductType.MS];
    const xp95Revenue = totals.xp95Liters * prices[ProductType.XP95];
    
    const grossCollection = hsdRevenue + msRevenue + xp95Revenue;
    const cashCollection = grossCollection - totals.ccReceivables - totals.debtors;
    const netBalance = cashCollection - totals.testingAmount - totals.otherExpenses;

    return {
      grossCollection,
      cashCollection,
      netBalance,
      totals,
      dateDisplay: new Date(viewDate).toLocaleDateString('en-IN', {
        weekday: 'long', day: '2-digit', month: 'short', year: 'numeric'
      })
    };
  }, [entries, prices, viewDate]);

  const shareViaWhatsApp = () => {
    const { totals, grossCollection, cashCollection, netBalance, dateDisplay } = dashboardData;
    const text = `*⛽ Petrol Bunk Report - ${dateDisplay}*\n\n` +
      `*Fuel Sales (Ltrs):*\n` +
      `HSD: ${totals.hsdLiters.toFixed(2)} L\n` +
      `MS: ${totals.msLiters.toFixed(2)} L\n` +
      `XP95: ${totals.xp95Liters.toFixed(2)} L\n\n` +
      `*Financial Summary:*\n` +
      `Gross Revenue: ₹${grossCollection.toLocaleString()}\n` +
      `CC Receivables: ₹${totals.ccReceivables.toLocaleString()}\n` +
      `Cash Collection: ₹${cashCollection.toLocaleString()}\n` +
      `Debtors: ₹${totals.debtors.toLocaleString()}\n` +
      `Testing Amt: ₹${totals.testingAmount.toLocaleString()}\n` +
      `Fleet Card Amt: ₹${totals.otherExpenses.toLocaleString()}\n\n` +
      `*✅ Net Available (Cash): ₹${netBalance.toLocaleString()}*`;
    
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`);
  };

  return (
    <div className="min-h-screen pb-12 bg-slate-50 flex flex-col">
      <Header 
        onAddEntry={() => setIsEntryOpen(true)} 
        viewDate={viewDate}
        onDateChange={setViewDate}
      />
      
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4 sm:mt-6 w-full">
        <div className="mb-4 sm:mb-6 flex flex-col sm:flex-row sm:items-center justify-between bg-white p-4 rounded-2xl shadow-sm border border-slate-100 gap-3">
          <div>
            <h2 className="text-[10px] sm:text-sm font-black text-slate-400 uppercase tracking-widest">Reporting For</h2>
            <p className="text-xs sm:text-sm font-bold text-blue-600 uppercase tracking-widest">{dashboardData.dateDisplay}</p>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Jump to</span>
            <input 
              type="date" 
              value={viewDate} 
              onChange={(e) => setViewDate(e.target.value)}
              className="bg-slate-50 border border-slate-200 p-2 rounded-lg text-xs font-black outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <SummaryCards 
          data={dashboardData}
          onShare={shareViaWhatsApp}
          onEditSettings={() => setIsSettingsOpen(true)}
        />
        
        <div className="mt-8 flex justify-center">
          <button 
            onClick={handleReset}
            className="text-[10px] font-black text-slate-300 hover:text-red-400 transition uppercase tracking-widest px-6 py-3 border border-slate-200 rounded-xl hover:bg-white"
          >
            Reset {new Date(viewDate).toLocaleDateString()} Data
          </button>
        </div>
      </main>

      {isEntryOpen && (
        <EntryModal 
          defaultDate={viewDate}
          onClose={() => setIsEntryOpen(false)}
          onSave={handleAddEntry}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal 
          prices={prices}
          onClose={() => setIsSettingsOpen(false)}
          onSave={setPrices}
        />
      )}
    </div>
  );
};

export default App;
