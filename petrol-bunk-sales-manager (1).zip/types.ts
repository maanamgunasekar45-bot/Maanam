
export enum ProductType {
  MS = 'MS',
  HSD = 'HSD',
  XP95 = 'XP95'
}

/* Configuration for fuel products including display name, default price, and UI color */
export interface ProductConfig {
  name: string;
  price: number;
  color: string;
}

export interface ProductPrices {
  [ProductType.MS]: number;
  [ProductType.HSD]: number;
  [ProductType.XP95]: number;
}

export interface DailySummary {
  date: string; // ISO string YYYY-MM-DD
  hsdLiters: number;
  msLiters: number;
  xp95Liters: number;
  ccReceivables: number;
  testingAmount: number;
  debtors: number;
  otherExpenses: number;
}

/* Detailed record of a sale based on meter readings */
export interface SaleEntry {
  id: string;
  timestamp: number;
  productType: ProductType;
  openingReading: number;
  closingReading: number;
  totalLiters: number;
  unitPrice: number;
  amount: number;
  note?: string;
}

/* Record of a collection entry (e.g., Credit Card or cash deposit) */
export interface CollectionEntry {
  id: string;
  timestamp: number;
  category: string;
  amount: number;
}

/* Record of an expense entry */
export interface ExpenseEntry {
  id: string;
  timestamp: number;
  category: string;
  amount: number;
}
