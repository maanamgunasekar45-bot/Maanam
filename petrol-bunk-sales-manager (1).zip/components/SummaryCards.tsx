
import React from 'react';

interface SummaryCardsProps {
  data: {
    grossCollection: number;
    cashCollection: number;
    netBalance: number;
    totals: any;
  };
  onShare: () => void;
  onEditSettings: () => void;
}

export const SummaryCards: React.FC<SummaryCardsProps> = ({ data, onShare, onEditSettings }) => {
  const { totals } = data;

  return (
    <div className="space-y-4 py-4">
      {/* Row 1: Sales Liters and Gross Collection */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatBox label="HSD Liters" value={totals.hsdLiters.toFixed(2)} unit="L" color="border-yellow-500" labelColor="text-yellow-600" />
        <StatBox label="MS Liters" value={totals.msLiters.toFixed(2)} unit="L" color="border-blue-500" labelColor="text-blue-600" />
        <StatBox label="XP95 Liters" value={totals.xp95Liters.toFixed(2)} unit="L" color="border-red-500" labelColor="text-red-600" />
        <StatBox label="Gross Collection" value={data.grossCollection.toLocaleString()} unit="₹" color="border-green-600" labelColor="text-green-700" isAmount />
      </div>

      {/* Row 2: Financial Inflows and Deductions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatBox label="CC Receivables" value={totals.ccReceivables.toLocaleString()} unit="₹" color="border-indigo-500" labelColor="text-indigo-600" isAmount />
        <StatBox label="Cash Collection" value={data.cashCollection.toLocaleString()} unit="₹" color="border-emerald-600" labelColor="text-emerald-600" isAmount />
        <StatBox label="Testing Amt" value={totals.testingAmount.toLocaleString()} unit="₹" color="border-orange-500" labelColor="text-orange-600" isAmount />
        <StatBox label="Debtors" value={totals.debtors.toLocaleString()} unit="₹" color="border-slate-400" labelColor="text-slate-600" isAmount />
      </div>

      {/* Row 3: Final Metrics and Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Box 9: Fleet Card Amt */}
        <StatBox label="Fleet Card Amt" value={totals.otherExpenses.toLocaleString()} unit="₹" color="border-rose-500" labelColor="text-rose-600" isAmount />
        
        {/* Box 10: Net Available */}
        <div className="bg-slate-900 p-5 rounded-2xl border-l-4 border-blue-400 shadow-xl flex flex-col justify-center">
            <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Net Available</p>
            <h3 className="text-xl font-black text-white">₹{data.netBalance.toLocaleString()}</h3>
        </div>
        
        {/* Box 11: WhatsApp Share */}
        <button 
          onClick={onShare}
          className="bg-green-600 p-5 rounded-2xl shadow-lg hover:bg-green-700 transition flex items-center justify-center gap-3 text-white active:scale-95 group h-full"
        >
          <div className="bg-white/20 p-2 rounded-lg group-hover:scale-110 transition">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 448 512">
                <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.7 17.7 69.1 27 106.2 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.2-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-5.5-2.8-23.2-8.5-44.2-27.1-16.4-14.6-27.4-32.7-30.6-38.2-3.2-5.5-.3-8.5 2.4-11.2 2.5-2.6 5.5-6.5 8.3-9.8 2.8-3.3 3.7-5.6 5.5-9.3 1.8-3.7.9-6.9-.5-9.8-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 13.2 5.8 23.5 9.2 31.6 11.8 13.3 4.2 25.4 3.6 35 2.2 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/>
            </svg>
          </div>
          <span className="font-black text-xs uppercase tracking-wider">WhatsApp</span>
        </button>

        {/* Box 12: Edit Settings */}
        <button 
          onClick={onEditSettings}
          className="bg-slate-200 p-5 rounded-2xl shadow-md hover:bg-slate-300 transition flex items-center justify-center gap-3 text-slate-800 active:scale-95 group h-full"
        >
          <div className="bg-slate-400/20 p-2 rounded-lg group-hover:rotate-45 transition">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <span className="font-black text-xs uppercase tracking-wider">Settings</span>
        </button>
      </div>
    </div>
  );
};

interface StatBoxProps {
  label: string;
  value: string;
  unit?: string;
  color: string;
  labelColor: string;
  isAmount?: boolean;
}

const StatBox = ({ label, value, unit, color, labelColor, isAmount = false }: StatBoxProps) => (
  <div className={`bg-white p-5 rounded-2xl border-l-4 shadow-sm transition-transform hover:scale-[1.02] ${color}`}>
    <p className={`text-[10px] font-black uppercase tracking-widest mb-1 ${labelColor}`}>{label}</p>
    <div className="flex items-baseline gap-1">
      {isAmount && <span className="text-xs font-bold text-slate-300">₹</span>}
      <h3 className="text-xl font-black text-slate-900 tracking-tight">{value}</h3>
      {!isAmount && <span className="text-[10px] font-bold text-slate-400 ml-0.5">{unit}</span>}
    </div>
  </div>
);
