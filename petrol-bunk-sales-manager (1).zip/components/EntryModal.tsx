
import React, { useState } from 'react';
import { DailySummary } from '../types';

interface EntryModalProps {
  defaultDate: string;
  onClose: () => void;
  onSave: (entry: DailySummary) => void;
}

export const EntryModal: React.FC<EntryModalProps> = ({ defaultDate, onClose, onSave }) => {
  const [date, setDate] = useState(defaultDate);
  const [hsdLiters, setHsdLiters] = useState('');
  const [msLiters, setMsLiters] = useState('');
  const [xp95Liters, setXp95Liters] = useState('');
  const [cc, setCc] = useState('');
  const [testing, setTesting] = useState('');
  const [debtors, setDebtors] = useState('');
  const [others, setOthers] = useState('');

  const handleFormSave = (e: React.FormEvent) => {
    e.preventDefault();
    
    const entry: DailySummary = {
      date,
      hsdLiters: parseFloat(hsdLiters) || 0,
      msLiters: parseFloat(msLiters) || 0,
      xp95Liters: parseFloat(xp95Liters) || 0,
      ccReceivables: parseFloat(cc) || 0,
      testingAmount: parseFloat(testing) || 0,
      debtors: parseFloat(debtors) || 0,
      otherExpenses: parseFloat(others) || 0
    };

    onSave(entry);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in duration-200">
        <div className="bg-slate-900 p-6 flex justify-between items-center sticky top-0 z-10">
          <h2 className="text-white font-black uppercase tracking-widest text-sm">New Sale Record</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <form onSubmit={handleFormSave} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Date Selection */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5">Reporting Date</label>
            <input 
              type="date" 
              value={date} 
              onChange={e => setDate(e.target.value)}
              className="w-full p-3 bg-white border border-slate-200 rounded-xl font-black text-slate-900 outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Liters Entry Section */}
          <div className="space-y-3">
             <div className="flex items-center gap-2">
                <div className="h-px flex-grow bg-slate-100"></div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Fuel Sales (Liters)</span>
                <div className="h-px flex-grow bg-slate-100"></div>
             </div>
             
             <div className="grid grid-cols-3 gap-3">
                <InputField label="HSD" value={hsdLiters} onChange={setHsdLiters} color="text-yellow-600" placeholder="0.00" />
                <InputField label="MS" value={msLiters} onChange={setMsLiters} color="text-blue-600" placeholder="0.00" />
                <InputField label="XP95" value={xp95Liters} onChange={setXp95Liters} color="text-red-600" placeholder="0.00" />
             </div>
          </div>

          {/* Financials Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
                <div className="h-px flex-grow bg-slate-100"></div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Financials (₹)</span>
                <div className="h-px flex-grow bg-slate-100"></div>
             </div>

            <div className="grid grid-cols-2 gap-3">
              <InputField label="CC Receivables" value={cc} onChange={setCc} color="text-indigo-600" />
              <InputField label="Testing Amt" value={testing} onChange={setTesting} color="text-orange-600" />
              <InputField label="Debtors" value={debtors} onChange={setDebtors} color="text-slate-500" />
              <InputField label="Fleet Card Amt" value={others} onChange={setOthers} color="text-rose-600" />
            </div>
          </div>

          <div className="flex gap-3 pt-4 sticky bottom-0 bg-white">
            <button type="button" onClick={onClose} className="flex-1 py-4 text-xs font-black text-slate-500 bg-slate-100 rounded-2xl hover:bg-slate-200 transition uppercase tracking-widest">Cancel</button>
            <button type="submit" className="flex-1 py-4 text-xs font-black text-white bg-blue-600 rounded-2xl hover:bg-blue-700 shadow-xl shadow-blue-500/20 transition uppercase tracking-widest">Save All</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const InputField = ({ label, value, onChange, color, placeholder = "0" }) => (
  <div>
    <label className={`block text-[10px] font-black uppercase tracking-widest mb-1 ${color}`}>{label}</label>
    <input 
      type="number" step="0.01" value={value} onChange={e => onChange(e.target.value)}
      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-black focus:ring-2 focus:ring-blue-500 outline-none text-sm" 
      placeholder={placeholder}
    />
  </div>
);
