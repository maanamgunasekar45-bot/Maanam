
// This file is deprecated in favor of components/EntryModal.tsx
export default null;
