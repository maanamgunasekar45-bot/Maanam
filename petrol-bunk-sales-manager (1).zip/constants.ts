
import { ProductType, ProductConfig } from './types';

export const PRODUCT_PRICES: Record<ProductType, ProductConfig> = {
  [ProductType.MS]: {
    name: 'Motor Spirit (Petrol)',
    price: 109.83,
    color: 'bg-blue-600'
  },
  [ProductType.HSD]: {
    name: 'High Speed Diesel',
    price: 97.6,
    color: 'bg-yellow-600'
  },
  [ProductType.XP95]: {
    name: 'XP95 (Premium)',
    price: 116.89,
    color: 'bg-red-600'
  }
};

export const CURRENCY = '₹';
